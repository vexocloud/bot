import discord
from discord.ext import commands
import os, sys
from dotenv import load_dotenv

DEBUG_MODE = "-debug" in sys.argv
load_dotenv()
TOKEN = os.getenv('BOT_TOKEN')
if not TOKEN: raise ValueError("No BOT_TOKEN found in environment variables")

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix='.', intents=intents)

@bot.event
async def on_ready():
    print(f'{bot.user} has logged in and is online!')
    await load_addons()

async def load_addons():
    for filename in os.listdir("./addons"):
        if filename.endswith(".py") and filename != "__init__.py":
            try: await bot.load_extension(f"addons.{filename[:-3]}"); print(f"Loaded addon: {filename}")
            except Exception as e: print(f"Failed to load addon {filename}: {e}")
    for addon_dir in os.listdir("./addons"):
        addon_path = os.path.join("./addons", addon_dir)
        if os.path.isdir(addon_path):
            for filename in os.listdir(addon_path):
                if filename.endswith(".py") and filename != "__init__.py":
                    try: await bot.load_extension(f"addons.{addon_dir}.{filename[:-3]}"); print(f"Loaded addon: {addon_dir}.{filename}")
                    except Exception as e: print(f"Failed to load addon {addon_dir}.{filename}: {e}")

@bot.command()
async def load(ctx, extension):
    try: await bot.load_extension(f"addons.{extension}"); await ctx.send(f"Loaded {extension}!")
    except Exception as e: await ctx.send(f"Failed to load {extension}: {e}")

@bot.command()
async def unload(ctx, extension):
    try: await bot.unload_extension(f"addons.{extension}"); await ctx.send(f"Unloaded {extension}!")
    except Exception as e: await ctx.send(f"Failed to unload {extension}: {e}")

@bot.command()
async def reload(ctx, extension):
    try: await bot.reload_extension(f"addons.{extension}"); await ctx.send(f"Reloaded {extension}!")
    except Exception as e: await ctx.send(f"Failed to reload {extension}: {e}")

if __name__ == "__main__": bot.run(TOKEN, log_handler=None if DEBUG_MODE else None)