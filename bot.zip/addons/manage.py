import discord
from discord.ext import commands
import asyncio
import sys
import json
import os

class VMManager(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.msgs_dir = os.path.join(os.path.dirname(__file__), "msgs")

    def load_message_template(self, template_name):
        """Load message template from JSON file"""
        try:
            file_path = os.path.join(self.msgs_dir, f"{template_name}.json")
            with open(file_path, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            print(f"Message template {template_name}.json not found!", file=sys.stderr)
            return None
        except json.JSONDecodeError:
            print(f"Error decoding JSON in {template_name}.json", file=sys.stderr)
            return None

    def create_embed_from_template(self, template_name, **kwargs):
        """Create Discord embed using a template with provided replacements"""
        template = self.load_message_template(template_name)
        if not template:
            # Fallback to basic embed if template not found
            return discord.Embed(
                title="Action Status",
                description=f"Operation completed with {template_name} template missing.",
                color=0x00ff00 if template_name == "success" else 0xff0000
            )

        # Replace placeholders in title and description
        title = template["title"].format(**kwargs)
        description = template["description"].format(**kwargs)

        # Map color string to actual color
        color_map = {
            "green": 0x00ff00,
            "red": 0xff0000,
            "blue": 0x0000ff
        }
        color = color_map.get(template.get("color", "green"), 0x00ff00)

        return discord.Embed(
            title=title,
            description=description,
            color=color
        )

    async def run_lxc_command(self, cmd):
        try:
            result = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            stdout, stderr = await result.communicate()
            return result.returncode, stdout.decode(), stderr.decode()
        except FileNotFoundError: return -1, "", "LXC is not installed or not in PATH"
        except Exception as e: return -1, "", str(e)

    async def get_container_status(self, vm_name):
        returncode, stdout, stderr = await self.run_lxc_command(['lxc-info', '-n', vm_name, '-s'])
        if returncode == 0:
            status_output = stdout.strip()
            if "RUNNING" in status_output: return "online"
            elif "STOPPED" in status_output: return "offline"
            for line in status_output.split('\n'):
                if line.startswith('State:'):
                    state = line.split(':', 1)[1].strip()
                    return 'online' if state == 'RUNNING' else 'offline'
        return "offline"

    async def get_container_uptime(self, name):
        returncode, stdout, stderr = await self.run_lxc_command(['lxc-info', '-n', name, '-H', '-s', '-u'])
        if returncode == 0:
            uptime_output = stdout.strip()
            return uptime_output if uptime_output and uptime_output not in ["0.00", "0.000"] else "Running"
        return "offline"

    @commands.command(name="create")
    async def create_vm(self, ctx, vm_name: str = None):
        if vm_name is None:
            await ctx.send("Please provide a name for the container. Usage: .create [container_name]")
            return
        if not vm_name.replace("-", "").replace("_", "").isalnum():
            embed = self.create_embed_from_template("failed", action="create", error="Invalid container name")
            await ctx.send(embed=embed)
            return
        print(f'DEBUG: Executing command: lxc-ls --fancy', file=sys.stderr)
        returncode, stdout, stderr = await self.run_lxc_command(['lxc-ls', '--fancy'])
        print(f'DEBUG: lxc-ls command exit code: {returncode}', file=sys.stderr)
        if stdout: print(f'DEBUG: lxc-ls stdout: {stdout.strip()}', file=sys.stderr)
        if stderr: print(f'DEBUG: lxc-ls stderr: {stderr.strip()}', file=sys.stderr)
        if returncode != 0:
            embed = self.create_embed_from_template("failed", action="check container status", error=stderr)
            await ctx.send(embed=embed)
            return
        if vm_name in stdout:
            embed = self.create_embed_from_template("failed", action=f"create container '{vm_name}'", error="Container already exists")
            await ctx.send(embed=embed)
            return
        print(f'Debug: {vm_name} creating started.', file=sys.stderr)
        print(f'Debug: [cmd] lxc-create -n {vm_name} -t download -- -d ubuntu -r jammy -a amd64', file=sys.stderr)
        await ctx.send(f"Creating container '{vm_name}'...")
        await ctx.send("Container creation initiated. This may take several minutes as it downloads the image...")
        returncode, stdout, stderr = await self.run_lxc_command(['lxc-create', '-n', vm_name, '-t', 'download', '--', '-d', 'ubuntu', '-r', 'jammy', '-a', 'amd64'])
        print(f'DEBUG: lxc-create command exit code: {returncode}', file=sys.stderr)
        if stdout: print(f'DEBUG: lxc-create stdout: {stdout.strip()}', file=sys.stderr)
        if stderr: print(f'DEBUG: lxc-create stderr: {stderr.strip()}', file=sys.stderr)
        if returncode == 0:
            print(f'Debug: success', file=sys.stderr)
            embed = self.create_embed_from_template("success", action=f"create container '{vm_name}'")
            await ctx.send(embed=embed)
        else:
            print(f'Debug: error', file=sys.stderr)
            embed = self.create_embed_from_template("failed", action="create container", error=stderr)
            await ctx.send(embed=embed)

    @commands.command(name="manage")
    async def manage_vm(self, ctx, vm_name: str = None):
        if vm_name is None:
            await ctx.send("Please provide a container name to manage. Usage: .manage [container_name]")
            return
        if not vm_name.replace("-", "").replace("_", "").isalnum():
            await ctx.send("Invalid container name. Use alphanumeric characters, hyphens, and underscores only.")
            return
        returncode, stdout, stderr = await self.run_lxc_command(['lxc-ls', '--fancy'])
        if returncode != 0 or vm_name not in stdout:
            await ctx.send(f"Container '{vm_name}' does not exist!")
            return
        status = await self.get_container_status(vm_name)
        embed = discord.Embed(title=f"Stats of {vm_name}", description=f"Managing {vm_name}", color=discord.Color.blue() if status == "online" else discord.Color.red())
        embed.add_field(name="Status", value=status.capitalize(), inline=False)
        view = LXCView(vm_name, self)
        await ctx.send(embed=embed, view=view)

    @commands.command(name="list-all")
    async def list_all_vms(self, ctx):
        returncode, stdout, stderr = await self.run_lxc_command(['lxc-ls', '--fancy'])
        if returncode != 0:
            await ctx.send(f"Error listing containers: {stderr}")
            return
        embed = discord.Embed(title="all 'VMS' list", color=0x3498db)
        if not stdout.strip():
            embed.description = "No containers found."
            await ctx.send(embed=embed, view=ListVMSView(self))
            return
        lines = stdout.strip().split('\n')
        if len(lines) <= 1:
            embed.description = "No containers found."
            await ctx.send(embed=embed, view=ListVMSView(self))
            return
        vm_list = ""
        counter = 1
        for line in lines[1:]:
            if line.strip():
                parts = line.split()
                if len(parts) >= 2:
                    name, state = parts[0], parts[1]
                    uptime = await self.get_container_uptime(name) if state == "RUNNING" else "offline"
                    status = "Online" if state == "RUNNING" else "Offline"
                    vm_list += f"{counter}.    [{name}]\n[{status}] - [{uptime}]\n"
                    counter += 1
        embed.description = vm_list if vm_list else "No containers found."
        await ctx.send(embed=embed, view=ListVMSView(self))

class LXCView(discord.ui.View):
    def __init__(self, vm_name, manager):
        super().__init__(timeout=60)
        self.vm_name = vm_name
        self.manager = manager

    async def handle_action(self, interaction, cmd, success_msg, fail_msg):
        returncode, stdout, stderr = await self.manager.run_lxc_command(cmd)
        if returncode == 0: await interaction.response.send_message(success_msg.format(self.vm_name), ephemeral=True)
        else: await interaction.response.send_message(fail_msg.format(self.vm_name, stderr), ephemeral=True)

    @discord.ui.button(label='Start', style=discord.ButtonStyle.primary, emoji='▶️')
    async def start_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.handle_action(interaction, ['lxc-start', '-n', self.vm_name, '-d'], "Started container '{}' successfully!", "Failed to start container '{}': {}")

    @discord.ui.button(label='Stop', style=discord.ButtonStyle.secondary, emoji='⏹️')
    async def stop_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.handle_action(interaction, ['lxc-stop', '-n', self.vm_name], "Stopped container '{}' successfully!", "Failed to stop container '{}': {}")

    @discord.ui.button(label='Delete', style=discord.ButtonStyle.danger, emoji='🗑️')
    async def delete_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.handle_action(interaction, ['lxc-destroy', '-n', self.vm_name, '-f'], "Deleted container '{}' successfully!", "Failed to delete container '{}': {}")

    @discord.ui.button(label='Refresh', style=discord.ButtonStyle.secondary, emoji='🔄')
    async def refresh_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        status = await self.manager.get_container_status(self.vm_name)
        embed = discord.Embed(title=f"Stats of {self.vm_name}", description=f"Managing {self.vm_name}", color=discord.Color.blue() if status == "online" else discord.Color.red())
        embed.add_field(name="Status", value=status.capitalize(), inline=False)
        await interaction.response.edit_message(embed=embed, view=self)

class ListVMSView(discord.ui.View):
    def __init__(self, manager):
        super().__init__(timeout=60)
        self.manager = manager

    async def update_vm_list(self, interaction):
        returncode, stdout, stderr = await self.manager.run_lxc_command(['lxc-ls', '--fancy'])
        embed = discord.Embed(title="all 'VMS' list", color=0x3498db)
        if returncode != 0:
            if interaction.response.is_done(): await interaction.followup.send(f"Error listing containers: {stderr}", ephemeral=True)
            else: await interaction.response.send_message(f"Error listing containers: {stderr}", ephemeral=True)
            return
        if not stdout.strip():
            embed.description = "No containers found."
            if interaction.response.is_done(): await interaction.edit_original_response(embed=embed, view=self)
            else: await interaction.response.edit_message(embed=embed, view=self)
            return
        lines = stdout.strip().split('\n')
        if len(lines) <= 1:
            embed.description = "No containers found."
            if interaction.response.is_done(): await interaction.edit_original_response(embed=embed, view=self)
            else: await interaction.response.edit_message(embed=embed, view=self)
            return
        vm_list, counter = "", 1
        for line in lines[1:]:
            if line.strip():
                parts = line.split()
                if len(parts) >= 2:
                    name, state = parts[0], parts[1]
                    uptime = await self.manager.get_container_uptime(name) if state == "RUNNING" else "offline"
                    status = "Online" if state == "RUNNING" else "Offline"
                    vm_list += f"{counter}.    [{name}]\n[{status}] - [{uptime}]\n"
                    counter += 1
        embed.description = vm_list if vm_list else "No containers found."
        if interaction.response.is_done(): await interaction.edit_original_response(embed=embed, view=self)
        else: await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(label='Refresh', style=discord.ButtonStyle.blurple, emoji='🔄')
    async def refresh_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.update_vm_list(interaction)

    @discord.ui.button(label='Delete All', style=discord.ButtonStyle.danger, emoji='🗑️')
    async def delete_all_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        returncode, stdout, stderr = await self.manager.run_lxc_command(['lxc-ls', '--fancy'])
        if returncode != 0:
            await interaction.response.send_message(f"Error getting containers to delete: {stderr}", ephemeral=True)
            return
        if not stdout.strip():
            await interaction.response.send_message("No containers to delete.", ephemeral=True)
            return
        lines = stdout.strip().split('\n')
        container_names = [line.split()[0] for line in lines[1:] if line.strip() and len(line.split()) >= 1]
        if not container_names:
            await interaction.response.send_message("No containers to delete.", ephemeral=True)
            return
        for name in container_names: await self.manager.run_lxc_command(['lxc-destroy', '-n', name, '-f'])
        await interaction.response.send_message(f"Deleted all {len(container_names)} containers.", ephemeral=True)
        await self.update_vm_list(interaction)

    @discord.ui.button(label='Stop All', style=discord.ButtonStyle.secondary, emoji='⏹️')
    async def stop_all_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        returncode, stdout, stderr = await self.manager.run_lxc_command(['lxc-ls', '--fancy'])
        if returncode != 0:
            await interaction.response.send_message(f"Error getting containers to stop: {stderr}", ephemeral=True)
            return
        if not stdout.strip():
            await interaction.response.send_message("No containers to stop.", ephemeral=True)
            return
        lines = stdout.strip().split('\n')
        running_containers = [line.split()[0] for line in lines[1:] if line.strip() and len(line.split()) >= 2 and line.split()[1] == "RUNNING"]
        if not running_containers:
            await interaction.response.send_message("No running containers to stop.", ephemeral=True)
            return
        for name in running_containers: await self.manager.run_lxc_command(['lxc-stop', '-n', name])
        await interaction.response.send_message(f"Stopped all {len(running_containers)} running containers.", ephemeral=True)
        await self.update_vm_list(interaction)

    @discord.ui.button(label='Start All', style=discord.ButtonStyle.success, emoji='▶️')
    async def start_all_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        returncode, stdout, stderr = await self.manager.run_lxc_command(['lxc-ls', '--fancy'])
        if returncode != 0:
            await interaction.response.send_message(f"Error getting containers to start: {stderr}", ephemeral=True)
            return
        if not stdout.strip():
            await interaction.response.send_message("No containers to start.", ephemeral=True)
            return
        lines = stdout.strip().split('\n')
        stopped_containers = [line.split()[0] for line in lines[1:] if line.strip() and len(line.split()) >= 2 and line.split()[1] == "STOPPED"]
        if not stopped_containers:
            await interaction.response.send_message("No stopped containers to start.", ephemeral=True)
            return
        for name in stopped_containers: await self.manager.run_lxc_command(['lxc-start', '-n', name, '-d'])
        await interaction.response.send_message(f"Started all {len(stopped_containers)} stopped containers.", ephemeral=True)
        await self.update_vm_list(interaction)

async def setup(bot):
    await bot.add_cog(VMManager(bot))